package com.vccare.mananwason.vcare;

/**
 * Created by mananwason on 9/17/17.
 */

public class CaptureDailyNote {
}
